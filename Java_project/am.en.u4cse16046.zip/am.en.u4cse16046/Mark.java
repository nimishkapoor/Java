

public interface Mark {
    public void setMark(int mark);
    public int getMark();
    public void addMark();
    public void printMark();
}

